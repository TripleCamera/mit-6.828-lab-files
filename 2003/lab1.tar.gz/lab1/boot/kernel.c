/*
 * Tiny kernel just to demonstrate that the boot loader works.
 * Assumes stack is set up properly (I mean, come on, we're in C!).
 * Is position-independent *except* that it computes out its own load
 * address and prints an error if it has been loaded in the wrong place.
 */

void cmain(int);

void
start(void)
{
	cmain(0);
}

void cgainit(void);
void consputs(char*);
void cgabanner(void);
void bochsbreak(void);
void uartputs(char*);
void lptputs(char*);
void *fix(void*);
void hextoa(char*, long);

static long linkaddr, loadaddr;

void
cmain(int x)
{
	char buf[10];
	long calladdr, callval, linkmain, loadmain;

	linkmain = (long)cmain;
	calladdr = ((long*)&x)[-1];	/* return address on stack */
	callval = *(long*)(calladdr-4);	/* address from 'call' instruction */
	loadmain = calladdr+callval;
	linkaddr = (long)start;
	loadaddr = linkaddr + loadmain - linkmain;

	cgainit();
	consputs(fix("The kernel link address is "));
	hextoa(buf, linkaddr);
	consputs(buf);
	consputs(fix(".\n"));
	consputs(fix("The kernel load address is "));
	hextoa(buf, loadaddr);
	consputs(buf);
	consputs(fix(".\n"));

	if(linkaddr != loadaddr){
		consputs(fix("The boot loader failed.\n"));
	}else{
		consputs(fix("The boot loader behaved properly.\n"));
	}

	bochsbreak();
	for(;;);
}

void*
fix(void *v)
{
	return (char*)v+loadaddr-linkaddr;
}

void
hextoa(char *a, long v)
{
	int i, c;

	for(i=0; i<8; i++){
		c = v&0xf;
		v >>= 4;
		if(c < 10)
			c += '0';
		else
			c += 'A'-10;
		a[7-i] = c;
	}
	a[8] = 0;
}

/*
 * Goop for printing to screen.
 */
typedef unsigned char uchar;

#include "io.h"
#define cgamem ((char*)0xB8000)

enum {
	Black,
	Blue,
	Green,
	Cyan,
	Red,
	Magenta,
	Brown,
	Grey,

	Bright = 0x08,
	Blinking = 0x80,

	Yellow = Bright|Brown,
	White = Bright|Grey,
};

enum {
	Width = 80*2,
	Height = 25,

	/* high background, low foreground */
	Attr = (Black<<4)|Grey,
};

int _cgapos;
#define cgapos (*(int*)fix(&_cgapos))

void*
memmove(void *a1, void *a2, unsigned long n)
{
	char *s1, *s2;

	if((long)n < 0)
		abort();
	s1 = a1;
	s2 = a2;
	if((s2 < s1) && (s2+n > s1))
		goto back;
	while(n > 0) {
		*s1++ = *s2++;
		n--;
	}
	return a1;

back:
	s1 += n;
	s2 += n;
	while(n > 0) {
		*--s1 = *--s2;
		n--;
	}
	return a1;
}

uchar
cgaregr(int index)
{
	outb(0x3D4, index);
	return inb(0x3D4+1) & 0xFF;
}

uchar
cgaregw(int index, int data)
{
	outb(0x3D4, index);
	outb(0x3D4+1, data);
}

void
movecursor(void)
{
	cgaregw(0x0E, (cgapos/2>>8) & 0xFF);
	cgaregw(0x0F, cgapos/2 & 0xFF);
	cgamem[cgapos+1] = Attr;
}

void
cgainit(void)
{
	int p;

	cgapos = cgaregr(0x0E)<<8;
	cgapos |= cgaregr(0x0F);
	cgapos *= 2;
}

void
cgaputc(int c)
{
	int i;
	uchar *p;

	if(c == '\n'){
		cgapos = cgapos/Width;
		cgapos = (cgapos+1)*Width;
	}
	else if(c == '\t'){
		i = 8 - ((cgapos/2)&7);
		while(i-->0)
			cgaputc(' ');
	}
	else if(c == '\b'){
		if(cgapos >= 2)
			cgapos -= 2;
		cgaputc(' ');
		cgapos -= 2;
	}
	else{
		cgamem[cgapos++] = c;
		cgamem[cgapos++] = Attr;
	}
	if(cgapos >= Width*Height){
		memmove(cgamem, &cgamem[Width], Width*(Height-1));
		p = &cgamem[Width*(Height-1)];
		for(i=0; i<Width/2; i++){
			*p++ = ' ';
			*p++ = Attr;
		}
		cgapos = Width*(Height-1);
	}
	movecursor();
}

void lptputc(int);
void
consputs(char *s)
{
	int i;
	for(i=0; *s && i++<40; s++){
		cgaputc(*s);
		lptputc(*s);
	}
}

void
cgabanner(void)
{
	int i;

	for(i=0; i<80; i++)
		cgamem[2*i+1] = (Blue<<4)|White;
}

void
abort(void)
{
	for(;;);
}

void
bochsbreak(void)
{
	outw(0x8A00, 0x8A00);
	outw(0x8A00, 0x8AE0);
}

void
delay(int n)
{
	int i, j;
	static int x;

	for(i=0; i<n; i++)
		for(j=0; j<10000; j++)
			x++;
}

int
uartgetc(void)
{
	while(!(inb(0x3F8+5)&0x01))
		delay(1);
	return inb(0x3F8+0);
}

void
uartputc(int c)
{
	int i;

	for(i=0; !(inb(0x3F8+5)&0x20) && i<12800; i++)
		delay(1);
	outb(0x3F8+0, c);
	for(i=0; !(inb(0x3F8+5)&0x20) && i<12800; i++)
		delay(1);
}

void
uartputs(char *s)
{
	for(; *s; s++)
		uartputc(*s);
}

void
lptputc(int c)
{
	int i;

	for(i=0; !(inb(0x378+1)&0x80) && i<12800; i++)
		delay(1);
	outb(0x378+0, c);
	outb(0x378+2, 0x08|0x01);
	outb(0x378+2, 0x08);
}

void
lptputs(char *s)
{
	int i;

	for(i=0; i<100 && *s; i++, s++)
		lptputc(*s);
}
