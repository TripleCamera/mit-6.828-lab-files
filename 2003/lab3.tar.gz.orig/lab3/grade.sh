#!/bin/sh

# Kernel will panic, which will drop back to debugger.
(echo "c"; echo "quit") | bochs-nogui 'parport1: enable=1, file="bochs.out"' 

score=0

XXX

