// idle loop

#include "lib.h"

void
umain(void)
{
	for(;;);
}

