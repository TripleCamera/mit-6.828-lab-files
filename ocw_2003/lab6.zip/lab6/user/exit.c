#include "lib.h"

void
umain(void)
{
}
