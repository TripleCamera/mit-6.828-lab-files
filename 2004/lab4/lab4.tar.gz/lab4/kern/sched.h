/* See COPYRIGHT for copyright information. */

#ifndef __SCHED_H__
#define __SCHED_H__

void sched_yield(void);

#endif /* __SCHED_H__ */
