
#include <inc/string.h>
#include <inc/lib.h>

void
cputchar(int ch)
{
	char s[2];

	// Unlike standard Unix's putchar,
	// the cputchar function _always_ outputs to the system console.
	// We do this in order to make debugging easier in JOS.

	s[0] = ch;
	s[1] = 0;
	sys_cputs(s);
}

int
getchar(void)
{
	return sys_cgetc();
}


